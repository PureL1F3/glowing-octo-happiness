Prerequisites:

- Node and NPM
- Gulp

Flow:

- Checkout `develop` branch
- Run `npm install` to get or update the dependencies
- Run `gulp`. Gulp will run the default task and listen for further files changes
- Work on the Coffeescript or LESS sources. Gulp will automatically build for you
- Once completed, submit a Pull Requests. Be sure to target `develop` as destination branch

Thank you.
